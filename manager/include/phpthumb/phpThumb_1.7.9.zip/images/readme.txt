If you're looking for the demo images, they can be downloaded from
the bottom of the phpThumb demo page on SourceForge:

http://phpthumb.sourceforge.net/demo/demo/phpThumb.demo.demo.php